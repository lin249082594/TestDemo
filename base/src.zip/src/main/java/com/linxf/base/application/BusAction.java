package com.linxf.base.application;

/**
 * 类说明
 * Created by Linxf on 2019/5/10.
 */

public class BusAction {
    public static final String REFRESH_CAST = "1";
}
