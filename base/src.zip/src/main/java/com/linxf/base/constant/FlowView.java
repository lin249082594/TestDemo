package com.linxf.base.constant;

import android.view.View;

/**
 * 类说明
 * Created by Linxf on 2019/4/11.
 */

public class FlowView {
    private String param;
    private View view;

    public String getParam() {
        return param;
    }

    public void setParam(String param) {
        this.param = param;
    }

    public View getView() {
        return view;
    }

    public void setView(View view) {
        this.view = view;
    }
}
