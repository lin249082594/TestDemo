package com.linxf.base.listener;

/**
 * 类说明
 * Created by Linxf on 2019/4/10.
 */

public interface OnPageRefreshListener  {
    void loadData();
    void noMoreData();


}
